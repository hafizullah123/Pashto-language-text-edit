<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pashto Spell Checker</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            max-width: 600px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
        }

        textarea {
            width: 100%;
            height: 100px;
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0056b3;
        }

        .result {
            margin-top: 20px;
        }

        .result p {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Pashto Spell Checker</h1>
        <form action="" method="post">
            <textarea name="text" placeholder="Enter your Pashto text here..."><?php echo isset($_POST['text']) ? htmlspecialchars($_POST['text']) : ''; ?></textarea>
            <button type="submit">Check Text</button>
        </form>

        <?php
        // Load dictionary from file
        $dictionaryFile = 'pashto_dictionary.txt';
        $dictionary = file($dictionaryFile, FILE_IGNORE_NEW_LINES);

        // Function to suggest corrections for misspelled word
        function suggestCorrection($misspelledWord, $dictionary) {
            $suggestions = [];
            foreach ($dictionary as $word) {
                // Calculate Levenshtein distance
                $levenshtein = levenshtein($misspelledWord, $word);
                // If distance is less than or equal to 2, consider it a suggestion
                if ($levenshtein <= 2) {
                    $suggestions[] = $word;
                }
            }
            return $suggestions;
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $inputText = $_POST['text'];

            // Spell checking and correction
            $userWords = preg_split("/\s+/u", $inputText); // Split text by whitespace (supports right-to-left)
            foreach ($userWords as &$word) {
                if (!in_array($word, $dictionary)) {
                    // Find suggestions for misspelled word
                    $suggestions = suggestCorrection($word, $dictionary);
                    // Replace misspelled word with first suggestion
                    if (!empty($suggestions)) {
                        $word = $suggestions[0];
                    }
                }
            }
            $correctedText = implode(' ', $userWords);

            // Display corrected text only
            echo "<div class=\"result\">";
            echo "<h2>Corrected Text:</h2>";
            echo "<p>$correctedText</p>";
            echo "</div>";
        }
        ?>
    </div>
</body>
</html>
