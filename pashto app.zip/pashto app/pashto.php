<?php
// Initialize pspell
$pspell_link = pspell_new("ps", "", "", "", "", PSPELL_FAST);

if (!isset($_POST['text'])) {
    die("Text not provided");
}

$text = $_POST['text'];

// Spell checking
$words = preg_split("/[\s,.]+/", $text);
$misspelled = [];
foreach ($words as $word) {
    if (!pspell_check($pspell_link, $word)) {
        $misspelled[] = $word;
    }
}

// Output results
echo "<h2>Spell Check Results:</h2>";
if (empty($misspelled)) {
    echo "<p>No misspelled words found.</p>";
} else {
    echo "<p>Misspelled words:</p>";
    echo "<ul>";
    foreach ($misspelled as $word) {
        echo "<li>$word</li>";
    }
    echo "</ul>";
}
?>
